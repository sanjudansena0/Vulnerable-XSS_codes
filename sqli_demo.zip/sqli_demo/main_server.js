const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const db = new sqlite3.Database(':memory:');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

db.serialize(() => {
    db.run("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)");
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Store name (vulnerable to SQLi)
app.post('/submit', (req, res) => {
    const name = req.body.name;
    db.run(`INSERT INTO users (name) VALUES ('${name}')`, function (err) {
        if (err) return res.send('Error inserting name.');
        res.send('Name submitted successfully! <a href="/">Go Back</a>');
    });
});

// View user by ID (vulnerable to SQLi)
app.get('/view/:id', (req, res) => {
    const id = req.params.id;
    const query = `SELECT * FROM users WHERE id = ${id}`;
    console.log('Query:', query);

    db.all(query, (err, rows) => {
        if (err) return res.send('Error occurred.');
        if (rows.length === 0) return res.send('No user found.');

        const names = rows.map(row => `<li>ID: ${row.id}, Name: ${row.name}</li>`).join('');
        res.send(`<h1>Users</h1><ul>${names}</ul><a href="/">Back</a>`);
    });
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
