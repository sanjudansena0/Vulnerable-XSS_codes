const express = require('express');
const app = express();
const path = require('path');

// Built-in middleware to serve static assets
app.use(express.static(path.join(__dirname, 'public')));

// Sanitization function: allow only letters
function sanitizeLetters(input) {
  return input
    .trim()
    .replace(/[^a-zA-Z]/g, '');  // remove non-letter characters
}

app.get('/search', (req, res) => {
  const raw = req.query.query || '';
  const clean = sanitizeLetters(raw);
  res.send(`
    <h1>Hello ${clean}</h1>
    <a href="/">Go back</a>
  `);
});

app.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});
