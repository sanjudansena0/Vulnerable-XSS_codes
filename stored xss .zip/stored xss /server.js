const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const db = new sqlite3.Database(':memory:'); // db ek temporary in-memory database hai jo restart karne par data reset ho jata hai.

// ye Middleware hai
app.use(bodyParser.urlencoded({ extended: false })); //
app.use(express.static(path.join(__dirname, 'public')));

// Create table with ID
db.serialize(() => {
  db.run("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)");
});

// Form page
app.get('/', (req, res) => {
  res.send(`
    <h1>Submit Your Name</h1>
    <form method="POST" action="/submit">
      <input type="text" name="name" placeholder="Enter your name" required />
      <button type="submit">Submit</button>
    </form>
    <a href="/all">View All Entries</a>
  `);
});

// Handle form submission
app.post('/submit', (req, res) => {
  const name = req.body.name;
  db.run("INSERT INTO users (name) VALUES (?)", [name], function(err) {
    if (err) return res.send("Error saving name.");
    res.redirect(`/view/${this.lastID}`); // Redirect to view by ID
  });
});

// View name by ID (Stored XSS vulnerable)
app.get('/view/:id', (req, res) => {
  const id = req.params.id;
  db.get("SELECT name FROM users WHERE id = ?", [id], (err, row) => {
    if (err || !row) return res.send("No name found.");
    
    res.send(`
      <h1>View Name by ID: ${id}</h1>
      <p>Name: ${row.name}</p>
      <a href="/">Submit Another Name</a> | <a href="/all">View All</a>
    `);
  });
});

// List all names with IDs
app.get('/all', (req, res) => {
  db.all("SELECT id, name FROM users", (err, rows) => {
    if (err) return res.send("Error retrieving data.");
    
    const list = rows.map(row => 
      `<li><a href="/view/${row.id}">ID ${row.id}:</a> ${row.name}</li>`).join('');
    res.send(`
      <h1>All Entries</h1>
      <ul>${list}</ul>
      <a href="/">Go Back</a>
    `);
  });
});

// Start server
app.listen(3000, () => {
  console.log("Server running at http://localhost:3000/");
});
