const express = require('express');
const { encode } = require('html-entities');
const path = require('path');

const app = express();

// Static folder se HTML serve karne ke liye
app.use(express.static(path.join(__dirname, 'public')));

// Form data ko parse karne ke liye
app.use(express.urlencoded({ extended: true }));

app.post('/submit', (req, res) => {
  const raw = req.body.name || '';
  const safe = encode(raw);
  res.send(`Safe value: ${safe}`);
});

app.listen(3000, () => console.log('🚀 Running on http://localhost:3000'));
