const express = require('express');
const path = require('path');

const app = express();

// HTML entity encoding helper
function escapeHTML(str) {
  return str.replace(/[&<>'"]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  })[tag]);
}

app.use(express.static(path.join(__dirname, 'public')));

app.get('/search', (req, res) => {
  const raw = req.query.query || '';
  const safe = escapeHTML(raw);

  res.send(`
    <!DOCTYPE html>
    <html>
      <head><meta charset="utf-8"><title>Safe Output</title></head>
      <body>
        <h1>Hello ${safe}</h1>
        <p>Raw input was: ${safe}</p>
        <a href="/">Go back</a>
      </body>
    </html>
  `);
});

app.listen(3000, () => {
  console.log('✅ Server running at http://localhost:3000');
});
